using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent;
using Terraria.Localization;
using Terraria.ModLoader;

namespace ExpansionKele.Content;

public abstract class BaseHoldOutProjectile : ModProjectile, ILocalizedModType, IModType
{
	public abstract int AssociatedItemID { get; }

	public virtual Vector2 GunTipPosition => base.Projectile.Center + Vector2.UnitX.RotatedBy(base.Projectile.rotation) * (float)base.Projectile.width * 0.5f;

	public virtual float RecoilResolveSpeed => 0.3f;

	public virtual float MaxOffsetLengthFromArm { get; }

	public virtual float OffsetXUpwards { get; }

	public virtual float OffsetXDownwards { get; }

	public virtual float BaseOffsetY { get; }

	public virtual float OffsetYUpwards { get; }

	public virtual float OffsetYDownwards { get; }

	public Player Owner { get; private set; }

	public Item HeldItem { get; private set; }

	public bool KeepRefreshingLifetime { get; set; } = true;

	public float OffsetLengthFromArm { get; set; }

	public float ExtraFrontArmRotation { get; set; }

	public float ExtraBackArmRotation { get; set; }

	public Player.CompositeArmStretchAmount FrontArmStretch { get; set; }

	public Player.CompositeArmStretchAmount BackArmStretch { get; set; }

	private Type AssociatedItemType => ItemLoader.GetItem(AssociatedItemID).GetType();

	private Asset<Texture2D> ItemTexture => TextureAssets.Item[AssociatedItemID];

	//public override LocalizedText DisplayName => CalamityUtils.GetItemName(AssociatedItemID);

	public override string Texture => (AssociatedItemType.Namespace + "." + AssociatedItemType.Name).Replace('.', '/');

	public override void SetDefaults()
	{
		base.Projectile.width = (base.Projectile.height = ((ItemTexture == null) ? 1 : ItemTexture.Width()));
		base.Projectile.tileCollide = false;
		base.Projectile.netImportant = true;
	}

	public override void OnSpawn(IEntitySource source)
	{
		OffsetLengthFromArm = MaxOffsetLengthFromArm;
	}

	public override bool ShouldUpdatePosition()
	{
		return false;
	}

	public override bool? CanDamage()
	{
		return false;
	}

	public override void AI()
	{
		if (Owner == null)
		{
			Player player2 = (Owner = Main.player[base.Projectile.owner]);
		}
		if (HeldItem == null)
		{
			Item item2 = (HeldItem = Owner.ActiveItem());
            
		}
		KillHoldoutLogic();
		ManageHoldout();
		HoldoutAI();
	}

	public virtual void KillHoldoutLogic()
	{
		if (Owner.CantUseHoldout())
		{
			base.Projectile.Kill();
		}
	}

	public virtual void ManageHoldout()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		Vector2 armPosition = Owner.RotatedRelativePoint(Owner.MountedCenter, reverseRotation: true);
		Vector2 ownerToMouse = Owner.Calamity().mouseWorld - armPosition;
		float holdoutDirection = base.Projectile.velocity.ToRotation();
		float proximityLookingUpwards = Vector2.Dot(ownerToMouse.SafeNormalize(Vector2.Zero), -Vector2.UnitY * Owner.gravDir);
		int direction = MathF.Sign(ownerToMouse.X);
		Vector2 lengthOffset = base.Projectile.rotation.ToRotationVector2() * OffsetLengthFromArm;
		Vector2 armOffset = default(Vector2);
		((Vector2)(ref armOffset))._002Ector(Utils.Remap(MathF.Abs(proximityLookingUpwards), 0f, 1f, 0f, (proximityLookingUpwards > 0f) ? OffsetXUpwards : OffsetXDownwards) * (float)direction, BaseOffsetY * Owner.gravDir + Utils.Remap(MathF.Abs(proximityLookingUpwards), 0f, 1f, 0f, (proximityLookingUpwards > 0f) ? OffsetYUpwards : OffsetYDownwards) * Owner.gravDir);
		base.Projectile.Center = armPosition + lengthOffset + armOffset;
		base.Projectile.velocity = holdoutDirection.AngleTowards(ownerToMouse.ToRotation(), 0.2f).ToRotationVector2();
		base.Projectile.rotation = holdoutDirection;
		base.Projectile.spriteDirection = direction;
		Owner.ChangeDir(direction);
		Owner.heldProj = base.Projectile.whoAmI;
		Owner.itemTime = (Owner.itemAnimation = 2);
		Owner.itemRotation = (base.Projectile.velocity * (float)base.Projectile.direction).ToRotation();
		float armRotation = (base.Projectile.rotation - (float)Math.PI / 2f) * Owner.gravDir + ((Owner.gravDir == -1f) ? ((float)Math.PI) : 0f);
		Owner.SetCompositeArmFront(enabled: true, FrontArmStretch, armRotation + ExtraFrontArmRotation * (float)direction);
		Owner.SetCompositeArmBack(enabled: true, BackArmStretch, armRotation + ExtraBackArmRotation * (float)direction);
		if (KeepRefreshingLifetime)
		{
			base.Projectile.timeLeft = 2;
		}
		if (OffsetLengthFromArm != MaxOffsetLengthFromArm)
		{
			OffsetLengthFromArm = MathHelper.Lerp(OffsetLengthFromArm, MaxOffsetLengthFromArm, RecoilResolveSpeed);
		}
		base.Projectile.netUpdate = true;
		base.Projectile.netSpam = 0;
	}

	public abstract void HoldoutAI();

	public override bool PreDraw(ref Color lightColor)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		Texture2D value = TextureAssets.Projectile[base.Type].Value;
		Main.EntitySpriteDraw(position: base.Projectile.Center - Main.screenPosition, rotation: base.Projectile.rotation + ((base.Projectile.spriteDirection == -1) ? ((float)Math.PI) : 0f), origin: value.Size() * 0.5f, effects: (SpriteEffects)((float)base.Projectile.spriteDirection * Owner.gravDir == -1f), texture: value, sourceRectangle: null, color: base.Projectile.GetAlpha(lightColor), scale: base.Projectile.scale * Owner.gravDir);
		return false;
	}

	public sealed override void SendExtraAI(BinaryWriter writer)
	{
		writer.Write(base.Projectile.rotation);
		writer.Write(KeepRefreshingLifetime);
		writer.Write(OffsetLengthFromArm);
		writer.Write7BitEncodedInt(base.Projectile.spriteDirection);
		SendExtraAIHoldout(writer);
	}

	public sealed override void ReceiveExtraAI(BinaryReader reader)
	{
		base.Projectile.rotation = reader.ReadSingle();
		KeepRefreshingLifetime = reader.ReadBoolean();
		OffsetLengthFromArm = reader.ReadSingle();
		base.Projectile.spriteDirection = reader.Read7BitEncodedInt();
		ReceiveExtraAIHoldout(reader);
	}

	public virtual void SendExtraAIHoldout(BinaryWriter writer)
	{
	}

	public virtual void ReceiveExtraAIHoldout(BinaryReader reader)
	{
	}
}
